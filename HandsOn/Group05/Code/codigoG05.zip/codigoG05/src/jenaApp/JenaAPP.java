package jenaApp;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import org.apache.http.client.cache.Resource;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.ontology.Ontology;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.util.FileManager;
import org.apache.jena.util.iterator.ExtendedIterator;
import org.apache.jena.vocabulary.VCARD;

public class JenaAPP {

	public static ResultSet getNombre (OntModel model){ // obtiene todos los nombres del ttl con links
		String queryString =
				"PREFIX vcard: <http://www.w3.org/2006/vcard/ns#>" +
						"PREFIX owl: <http://www.w3.org/2002/07/owl#>" +
						"SELECT ?nombre ?uri "+
						"WHERE {?s vcard:given-name ?nombre;"
						+ "owl:sameAs ?uri.}";
		Query query = QueryFactory.create(queryString);
		QueryExecution qexec = QueryExecutionFactory.create(query, model) ;
		ResultSet results = qexec.execSelect() ;
		return results;
	}
	public static void printName (ResultSet results){ // imprime toddos los nombres del csv con links
		while (results.hasNext())
		{
			QuerySolution binding = results.nextSolution();
			Literal subj = binding.getLiteral("nombre");
			System.out.println(subj);
		}
	}
	public static ResultSet getProperties(OntModel model, String subj){ //obtiene todas nuestras propiedades
		String queryString =
				"PREFIX vcard: <http://www.w3.org/2006/vcard/ns#>" +
						"PREFIX owl: <http://www.w3.org/2002/07/owl#>" +
						"SELECT ?name ?street ?note ?region ?locality ?pc ?email ?tel ?uri "+
						"WHERE {?s vcard:given-name \"" + subj + "\";"
								+ "vcard:given-name ?name;"
								+ "vcard:street-address ?street;"
								+ "vcard:note ?note;"
								+ "vcard:region ?region;"
								+ "vcard:locality ?locality;"
								+ "vcard:postal-code ?pc;"
								+ "vcard:email ?email;"
								+ "vcard:tel ?tel;"
								+ "owl:sameAs ?uri .}";
		Query query = QueryFactory.create(queryString);
		QueryExecution qexec = QueryExecutionFactory.create(query, model);
		ResultSet results = qexec.execSelect();
		return results;
	}
	public static String printAll (ResultSet results){ //imprime todas nuestras propiedades
		String uriString = "";
		while (results.hasNext())
		{
			QuerySolution binding = results.nextSolution();
			Literal name = binding.getLiteral("name");
			Literal street = binding.getLiteral("street");
			Literal note = binding.getLiteral("note");
			Literal region = binding.getLiteral("region");
			Literal locality = binding.getLiteral("locality");
			Literal pc = binding.getLiteral("pc");
			Literal tel = binding.getLiteral("tel");
			Literal email = binding.getLiteral("email");
			org.apache.jena.rdf.model.Resource uri = binding.getResource("uri");
			System.out.println("------------------------------------------");
			String telf = tel.toString().substring(0, 11);
			System.out.println(name.toString() +"\n"+ street.toString() +", "+ note.toString() +"\n" + locality.toString() +", " + region.toString()  +"\n"+ pc.toString() +"\n"+ email.toString() +"\n"+ telf + "\nInfo: "+ uri.toString());
			System.out.println("------------------------------------------");
			uriString=uri.toString();
		}
		return uriString;
	}
	public static void listAll (OntModel model, ResultSet rs){
		while(rs.hasNext()){
			ResultSet r = getProperties(model, rs.nextSolution().getLiteral("nombre").toString());
			printAll(r);
		}
	}
	public static String consultaSparql(String uri){ //obtiene el primer enlace
		String [] ex2 = null;
		if(!uri.equals("")){
			String s2 = "PREFIX db: <http://dbpedia.org/resource/>"+
				"PREFIX wiki: <http://www.wikidata.org/entity/>"+
				"PREFIX dp: <http://dbpedia.org/page/>"+
				"select ?property ?value "+
				"where { {"+
				" <"+uri+"> ?property ?value. "+
				"}union{?value ?property <"+uri+"> . }}";
        Query query = QueryFactory.create(s2); //s2 = the query above
        QueryExecution qExe = QueryExecutionFactory.sparqlService( "http://dbpedia.org/sparql", query );
        ResultSet results2 = qExe.execSelect();
        //System.out.println("\n URL: "+uri);
        String copia ="";
        while(results2.hasNext()) copia = copia + results2.next();
        String [] ex1;
        if (copia.contains("http://dbpedia.org/resource/")){
        	ex1 = copia.split("http://dbpedia.org/resource/");
            ex2 = ex1[1].split(">");
        } else{ return uri;} //para wikidata
        wiki(uri);
        return ex2[0]; 		 //para dbpedia
		}  					 //el else de abajo es si no existe
		else {System.out.println("ERROR[consultaSparql]: nombre de la búsqueda incorrecto"); return "";}
	}

	public static void wiki(String uri){ //wikidata o 1º dbpedia
		String [] ex2 = null;
		System.out.println("\n URL: "+uri);
		String s2 = "PREFIX db: <http://dbpedia.org/resource/>"+
				"PREFIX wiki: <http://www.wikidata.org/entity/>"+
				"PREFIX dp: <http://dbpedia.org/page/>"+
				"select ?property ?value "+
				"where { {"+
				" <"+uri+"> ?property ?value. "+
				"}union{?value ?property <"+uri+"> . }}";
        Query query = QueryFactory.create(s2); //s2 = the query above
        QueryExecution qExe = QueryExecutionFactory.sparqlService( "http://dbpedia.org/sparql", query );
        ResultSet results = qExe.execSelect();
        ResultSetFormatter.out(System.out, results, query) ;
	}

	public static void consultaSparql2(String texto){ //envia a wikidata o imprime dbpedia
		if (texto.contains("http:")) wiki(texto);
		else{
			if(!texto.equals("")){
			String s2 = "PREFIX db: <http://dbpedia.org/resource/> "
					+ "PREFIX wiki: <http://www.wikidata.org/entity/> "
					+ "PREFIX dp: <http://dbpedia.org/page/> "
					+ "select ?property ?value where{ "
					+ "{<http://dbpedia.org/resource/"+texto+"> ?property ?value.} "
					+ "union{?value ?property <http://dbpedia.org/resource/"+texto+"> .} "
					+ "}";
        Query query = QueryFactory.create(s2); //s2 = the query above
        QueryExecution qExe = QueryExecutionFactory.sparqlService( "http://dbpedia.org/sparql", query );
        ResultSet results = qExe.execSelect();
        System.out.println("\n URL: http://dbpedia.org/resource/"+texto);
        ResultSetFormatter.out(System.out, results, query) ;
        }
		}
	}
	public static void main(String args[]) {
		String filename1 = "Turismo-updated-with-links.ttl";
		String filename2 = "Bibliotecas-updated-with-links.ttl";
		String filename3 = "Polideportivos-updated-with-links.ttl";
		String filename4 = "Centros-Culturales-updated-with-links.ttl";
		String uri="";

		// Create an empty model
		OntModel sitios_turisticos = ModelFactory.createOntologyModel(OntModelSpec.RDFS_MEM);
		OntModel bibliotecas = ModelFactory.createOntologyModel(OntModelSpec.RDFS_MEM);
		OntModel polideportivos = ModelFactory.createOntologyModel(OntModelSpec.RDFS_MEM);
		OntModel centros_culturales = ModelFactory.createOntologyModel(OntModelSpec.RDFS_MEM);

		// Use the FileManager to find the input file
		FileInputStream in1 = null;
		FileInputStream in2 = null;
		FileInputStream in3 = null;
		FileInputStream in4 = null;
		try {
			in1 = new FileInputStream(filename1);
			in2 = new FileInputStream(filename2);
			in3 = new FileInputStream(filename3);
			in4 = new FileInputStream(filename4);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// Read and mix the TTL file
		sitios_turisticos.read(in1,null,"TTL");
		bibliotecas.read(in2,null,"TTL");
		polideportivos.read(in3,null,"TTL");
		centros_culturales.read(in4,null,"TTL");



		//Pruebas

		/* Sitios turísticos: mostramos todos los nombres de sitios turisticos*/
		//printName(getNombre(sitios_turisticos));

		/* Bibliotecas: mostramos todos los nombres de las bibliotecas */
		//printName(getNombre(bibliotecas));

		/* Centros Culturales: mostramos todos los nombres de los centros culturales */
		//printName(getNombre(centros_culturales));

		/* Polideportivos: mostramos todos los nombres de los polideportivos */
		//printName(getNombre(polideportivos));

		/* Mostramos todo el contenido nuestro de todos los centros culturales */
		//listAll(sitios_turisticos, getNombre(sitios_turisticos));

		/* Mostramos todo el contenido nuestro de todos los centros culturales */
		//listAll(centros_culturales, getNombre(centros_culturales));

		/* Mostramos todo el contenido nuestro de todas las bibliotecas */
		//listAll(bibliotecas, getNombre(bibliotecas));

		/*Seleccionamos un sitio turístico con dbpedia*/
		//uri=printAll(getProperties(sitios_turisticos, "Museo Taurino de la Plaza de las Ventas"));
		//String dbpedia1 = consultaSparql(uri);
		//consultaSparql2(dbpedia1);

		//Otro ejemplo con dbpedia
		//uri=printAll(getProperties(sitios_turisticos, "Museo de América"));
		//consultaSparql2(consultaSparql(uri));

		//Ejemplo con wikidata
		//uri=printAll(getProperties(sitios_turisticos, "Museo Geominero"));
		//consultaSparql2(consultaSparql(uri));

		/*Seleccionamos un sitio turístico que no existe */
		//uri=printAll(getProperties(sitios_turisticos, "Plaza FIUPM"));
		//consultaSparql2(consultaSparql(uri));

		/* Seleccionamos otro lugar */
		//uri=printAll(getProperties(bibliotecas, "Centro Social y Cultural la Casa Encendida"));
		//consultaSparql2(consultaSparql(uri));



		// PRUEBAS

		/* Sitios turísticos: mostramos todos los nombres */
		//printName(getNombre(sitios_turisticos));

		/* Mostramos todo el contenido de todos*/
		//listAll(sitios_turisticos, getNombre(sitios_turisticos));

		/*Seleccionamos un sitio turístico con dbpedia*/
		//uri=printAll(getProperties(sitios_turisticos, "Museo Taurino de la Plaza de las Ventas"));
		//String dbpedia1 = consultaSparql(uri);
		//consultaSparql2(dbpedia1);

		//Otro ejemplo con dbpedia
		uri=printAll(getProperties(sitios_turisticos, "Museo de América"));
		consultaSparql2(consultaSparql(uri));

		//Ejemplo con wikidata
		//uri=printAll(getProperties(sitios_turisticos, "Museo Geominero"));
		//consultaSparql2(consultaSparql(uri));

	}
}
