/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package websemantica;

/**
 *
 * @author Raul
 */
public class Campos {
    private String titulo;
    private String provincia;
    private String localidad;
    private String organismoGestor;

    /**
     * @return the provincia
     */
    public String getProvincia() {
        return provincia;
    }

    /**
     * @param provincia the provincia to set
     */
    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    /**
     * @return the localidad
     */
    public String getLocalidad() {
        return localidad;
    }

    /**
     * @param localidad the localidad to set
     */
    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    /**
     * @return the organismoGestor
     */
    public String getOrganismoGestor() {
        return organismoGestor;
    }

    /**
     * @param organismoGestor the organismoGestor to set
     */
    public void setOrganismoGestor(String organismoGestor) {
        this.organismoGestor = organismoGestor;
    }

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
}
