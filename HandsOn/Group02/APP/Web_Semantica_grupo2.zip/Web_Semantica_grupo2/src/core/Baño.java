package core;

public class Ba�o {

	private String servicio;
	private String direccion;
	private String x;
	private String y;
	private String accesibilidad;
	private String cambiadorBaby;
	private String cambiador;
	private String ba�osFamiliares;
	private String horaApertura;
	private String AdministradoPor;
	private String email;
	private String tel;
	private String notas;
	private String cp;
	
	private Ba�o(String servicio,String direccion,String x,String y, String acc,String cb,String cam,String bf,String horaApertura,String admin,String email,String tel,String notas,String cp) {
		
		this.setServicio(servicio);
		this.setDireccion(direccion);
		this.setX(x);
		this.setY(y);
		this.setAccesibilidad(acc);
		this.setCambiadorBaby(cb);
		this.setCambiador(cam);
		this.setBa�osFamiliares(bf);
		this.setHoraApertura(horaApertura);
		this.setAdministradoPor(admin);
		this.setEmail(email);
		this.setTel(tel);
		this.setNotas(notas);
		this.setCp(cp);
		}
	public static Ba�o getInstance(String servicio,String direccion,String x,String y, String acc,String cb,String cam,String bf,String horaApertura,String admin,String email,String tel,String notas,String cp){
		return new Ba�o(servicio, direccion, x, y,  acc, cb, cam, bf, horaApertura, admin, email, tel, notas, cp);
	}
	public String getServicio() {
		return servicio;
	}
	public void setServicio(String servicio) {
		this.servicio = servicio;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getX() {
		return x;
	}
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}
	public String getAccesibilidad() {
		return accesibilidad;
	}
	public void setAccesibilidad(String accesibilidad) {
		this.accesibilidad = accesibilidad;
	}
	public String getCambiadorBaby() {
		return cambiadorBaby;
	}
	public void setCambiadorBaby(String cambiadorBaby) {
		this.cambiadorBaby = cambiadorBaby;
	}
	public String getCambiador() {
		return cambiador;
	}
	public void setCambiador(String cambiador) {
		this.cambiador = cambiador;
	}
	public String getBa�osFamiliares() {
		return ba�osFamiliares;
	}
	public void setBa�osFamiliares(String ba�osFamiliares) {
		this.ba�osFamiliares = ba�osFamiliares;
	}
	public String getHoraApertura() {
		return horaApertura;
	}
	public void setHoraApertura(String horaApertura) {
		this.horaApertura = horaApertura;
	}
	public String getAdministradoPor() {
		return AdministradoPor;
	}
	public void setAdministradoPor(String administradoPor) {
		AdministradoPor = administradoPor;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	public String getCp() {
		return cp;
	}
	public void setCp(String cp) {
		this.cp = cp;
	}
}
