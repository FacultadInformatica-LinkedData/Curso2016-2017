package core;

public class Restaurante {
	private String nombre;
	private String direccion;
	private String categoria;
	private String localizacion;
	private String latitud;
	private String longitud;
	private String detalles;
	private String critica;
	
	private Restaurante(String nombre,String direccion,String categoria,String localizacion, String lat,String lon,String detalles,String critica) {
		
		this.setNombre(nombre);
		this.setDireccion(direccion);
		this.setCategoria(categoria);
		this.setLocalizacion(localizacion);
		this.setLatitud(lat);
		this.setLongitud(lon);
		this.setDetalles(detalles);
		this.setCritica(critica);
		}
	public static Restaurante getInstance(String nombre,String direccion,String categoria,String localizacion, String lat,String lon,String detalles,String critica){
		return new Restaurante(nombre,direccion,categoria,localizacion,lat,lon,detalles,critica);
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getLocalizacion() {
		return localizacion;
	}
	public void setLocalizacion(String localizacion) {
		this.localizacion = localizacion;
	}
	public String getLatitud() {
		return latitud;
	}
	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}
	public String getLongitud() {
		return longitud;
	}
	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}
	public String getDetalles() {
		return detalles;
	}
	public void setDetalles(String detalles) {
		this.detalles = detalles;
	}
	public String getCritica() {
		return critica;
	}
	public void setCritica(String critica) {
		this.critica = critica;
	}

	
	
}
