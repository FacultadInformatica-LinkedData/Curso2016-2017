package core;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.sparql.engine.http.QueryEngineHTTP;
import org.apache.jena.sparql.pfunction.library.str;

import com.fasterxml.jackson.databind.util.PrimitiveArrayBuilder;

public class Core {

	public static final String paradas_metro = "https://raw.githubusercontent.com/Ismmael/Curso2016-2017/master/HandsOn/Group02/RDF/rdfAPP/London-stations-csv.rdf";
	public static final String paradas_bus = "https://raw.githubusercontent.com/Ismmael/Curso2016-2017/master/HandsOn/Group02/RDF/rdfAPP/Bus-Londres%20.rdf";
	public static final String restaurante = "https://raw.githubusercontent.com/Ismmael/Curso2016-2017/master/HandsOn/Group02/RDF/rdfAPP/london-restaurant-csv.rdf";
	public static final String ba�o = "https://raw.githubusercontent.com/Ismmael/Curso2016-2017/master/HandsOn/Group02/RDF/rdfAPP/public-toilets-csv.rdf";
	
	public static String pref1 = "http://www.semanticweb.org/webSemantica/grupo02/vocabulary#";
	public static String pref2 = "http://www.semanticweb.org/webSemantica/grupo02/";
	public static String pref3 = "http://dbpedia.org/ontology/";
	
	private ArrayList<Parada_Metro> paradasMetro = null;
	private ArrayList<Parada_bus> paradasbus = null;
	private ArrayList<Restaurante> restaurantes = null;
	private ArrayList<Ba�o> ba�os = null;
	
	

	private Core() {
		rellenarMetro();
		rellenarbus();
		rellenarba�os();
		rellenarRestaurantes();
	}

	public static Core getInstance() {
		
		return new Core();
	}

	public ResultSet getResults(String rdfName, String qry) {
		ResultSet results = null;
		try {
			URLConnection conn = new URL(rdfName).openConnection();
			InputStream in = conn.getInputStream();
			Model model = ModelFactory.createDefaultModel();
			if (in == null)
				throw new IllegalArgumentException("File: " + " not found");
			model.read(in, null);
			Query query = QueryFactory.create(qry);
			QueryExecution qexec = QueryExecutionFactory.create(query, model);
			results = qexec.execSelect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return results;
	}

	public void rellenarMetro() {
		this.paradasMetro = new ArrayList<>();
		String grupo = "gp02";
		String qry = "PREFIX " + "gp2" + ": <" + pref2 + "> " + "PREFIX " + "gp02" + ": <" + pref1 + ">  "
				+ "SELECT ?Subject ?nombre ?pa ?linea ?CoordX ?CoordY ?lat ?lon ?zona ?cp " 
				+ "WHERE { ?Subject " + grupo+ ":tieneNombre ?nombre." + 
					"?Subject " + grupo + ":tieneParadasAdyacentes ?pa."
						+"?Subject " + grupo + ":tieneLinea ?linea." + 
							"?Subject " + grupo + ":tieneCoordenada-X ?CoordX." 
								+ "?Subject " + grupo + ":tieneCoordenada-Y ?CoordY." 	
									+ "?Subject " + grupo + ":tieneLatitud ?lat." 
											+ "?Subject " + grupo + ":tieneLongitud ?lon." 
												+ "?Subject " + grupo + ":tieneZona ?zona." + 
													"?Subject " + grupo + ":tieneCodigoPostal ?cp."
														
															+ " } ";
		ResultSet results = getResults(paradas_metro, qry);
		while (results.hasNext()) {
			QuerySolution binding = results.nextSolution();
			Literal nombre = binding.getLiteral("nombre");
			Literal linea = binding.getLiteral("linea");
			Literal coordX = binding.getLiteral("CoordX");
			Literal coordY = binding.getLiteral("CoordY");
			Literal lat = binding.getLiteral("lat");
			Literal lon = binding.getLiteral("lon");
			Literal zona = binding.getLiteral("zona");
			Literal cp = binding.getLiteral("cp");
			Literal pa = binding.getLiteral("pa");

			Parada_Metro par = Parada_Metro.getInstance(nombre.getString(),pa.getString(), linea.getString(), coordX.getString(),
					coordY.getString(), lat.getString(), lon.getString(), zona.getString(), cp.getString());
			paradasMetro.add(par);
		}
	}
	
	public void rellenarbus() {
		this.paradasbus = new ArrayList<>();
		String grupo = "gp02";
		String qry = "PREFIX " + "gp2" + ": <" + pref2 + "> " + "PREFIX " + "gp02" + ": <" + pref1 + ">  "
				+ "SELECT ?Subject ?nombre ?cp ?CoordX ?CoordY ?sentido ?area " 
				+ "WHERE { ?Subject " + grupo+ ":tieneNombre ?nombre." + 
					"?Subject " + grupo + ":tieneCodigoDeParada ?cp."
							+"?Subject " + grupo + ":tieneCoordenada-X ?CoordX." 
								+ "?Subject " + grupo + ":tieneCoordenada-Y ?CoordY." 	
										+ "?Subject " + grupo + ":tieneSentido ?sentido." + 
													"?Subject " + grupo + ":tieneAreaParada ?area."				
															+ " } ";
		ResultSet results = getResults(paradas_bus, qry);
		while (results.hasNext()) {
			QuerySolution binding = results.nextSolution();
			Literal nombre = binding.getLiteral("nombre");
			Literal codigo = binding.getLiteral("cp");
			Literal coordX = binding.getLiteral("CoordX");
			Literal coordY = binding.getLiteral("CoordY");
			Literal sentido = binding.getLiteral("sentido");
			Literal area = binding.getLiteral("area");
			Parada_bus par = Parada_bus.getInstance(nombre.getString(),codigo.getString(),coordX.getString(),
					coordY.getString(),sentido.getString(), area.getString());
			paradasbus.add(par);
		}
	}
	
	public void rellenarRestaurantes() {
		this.restaurantes = new ArrayList<>();
		String grupo = "gp02";
		String qry = "PREFIX " + "gp2" + ": <" + pref2 + "> " + "PREFIX " + "gp02" + ": <" + pref1 + ">  "
				+ "SELECT ?Subject ?nombre ?direccion ?categoria ?localizacion ?lat ?lon ?detalles ?critica " 
				+ "WHERE { ?Subject " + grupo+ ":tieneNombre ?nombre." + 
					"?Subject " + grupo + ":tieneDireccion-Restaurante ?direccion."
							+"?Subject " + grupo + ":tieneCategoria ?categoria." 
								+ "?Subject " + grupo + ":tieneLocalizacion ?localizacion." 	
										+ "?Subject " + grupo + ":tieneLatitud ?lat." + 
													"?Subject " + grupo + ":tieneLongitud ?lon."		
														+"?Subject " + grupo + ":tieneDetalles ?detalles."
															+"?Subject " + grupo + ":tieneCritica ?critica."
															+ " } ";
		ResultSet results = getResults(restaurante, qry);
		while (results.hasNext()) {
			QuerySolution binding = results.nextSolution();
			Literal nombre = binding.getLiteral("nombre");
			Literal direccion = binding.getLiteral("direccion");
			Literal cat = binding.getLiteral("categoria");
			Literal localizacion = binding.getLiteral("localizacion");
			Literal lat  = binding.getLiteral("lat");
			Literal lon = binding.getLiteral("lon");
			Literal detalles = binding.getLiteral("detalles");
			Literal critica = binding.getLiteral("critica");
			
			String criticastr = "No disponible";
			if(critica!=null)
				criticastr=critica.getString();
			System.out.println(criticastr);
			Restaurante res = Restaurante.getInstance(nombre.getString(),direccion.getString(),cat.getString(),
					localizacion.getString(),lat.getString(), lon.getString(),detalles.getString(),criticastr);
			System.out.println(res.getNombre());
			restaurantes.add(res);
		}
	}
	
	
	public void rellenarba�os() {
		this.ba�os = new ArrayList<>();
		String grupo = "gp02";
		String qry = "PREFIX " + "gp2" + ": <" + pref2 + "> " + "PREFIX " + "gp02" + ": <" + pref1 + ">  "
				+ "SELECT ?Subject ?servicio ?direccion ?coordX ?coordY ?accesibilidad ?cb ?cam ?bf ?horaApertura ?admin ?email ?tel ?notas ?cp " 
				+ "WHERE { ?Subject " + grupo+ ":tieneServicio ?servicio." + 
					"?Subject " + grupo + ":tieneDireccion-Banio ?direccion."
							+"?Subject " + grupo + ":tieneCoordenada-X ?coordX." 
								+ "?Subject " + grupo + ":tieneCoordenada-Y ?coordY." 	
										+ "?Subject " + grupo + ":tieneCategoriaAccesible ?accesibilidad." + 
													"?Subject " + grupo + ":tieneCambiadorDeBebe ?cb."	
														+"?Subject " + grupo + ":tieneCambiador ?cam."	
															+"?Subject " + grupo + ":tieneBaniosFamiliares ?bf."
																+"?Subject " + grupo + ":tieneHoraDeApertura ?horaApertura."
																	+"?Subject " + grupo + ":administradoPor ?admin."
																		+"?Subject " + grupo + ":tieneEmailDeContacto ?email."
																			+"?Subject " + grupo + ":tieneTelefonoDeContacto ?tel."
																				+"?Subject " + grupo + ":tieneNotas ?notas."
																					+"?Subject " + grupo + ":tieneCodigoPostal ?cp."
																+ " } ";
		ResultSet results = getResults(ba�o, qry);
		while (results.hasNext()) {
			QuerySolution binding = results.nextSolution();
			Literal servicio = binding.getLiteral("servicio");
			Literal direccion = binding.getLiteral("direccion");
			Literal X = binding.getLiteral("coordX");
			Literal Y = binding.getLiteral("coordY");
			Literal accesibilidad = binding.getLiteral("accesibilidad");
			Literal cambiadorBebe = binding.getLiteral("cb");
			Literal cambiador = binding.getLiteral("cam");
			Literal ba�osFamiliares = binding.getLiteral("bf");
			Literal horaApertura = binding.getLiteral("horaApertura");
			Literal admin = binding.getLiteral("admin");
			Literal email = binding.getLiteral("email");
			Literal tel = binding.getLiteral("tel");
			Literal notas = binding.getLiteral("notas");
			Literal cp = binding.getLiteral("cp");
			
			Ba�o banio = Ba�o.getInstance(servicio.getString(),direccion.getString(),X.getString(),
					Y.getString(),accesibilidad.getString(), cambiadorBebe.getString(),cambiador.getString(),ba�osFamiliares.getString(),horaApertura.getString(),admin.getString(),email.getString(),tel.getString(),
					notas.getString(),cp.getString());
			System.out.println(banio.getServicio());
			ba�os.add(banio);
		}
	}

	public ArrayList<Parada_Metro> getMetros() {
		if(this.paradasMetro == null){
			rellenarMetro();
			Collections.sort(paradasMetro,new Comparator<Parada_Metro>() {
				 @Override
			        public int compare(Parada_Metro p1, Parada_Metro p2)
			        {
	
			            return  p1.getNombre().compareTo(p2.getNombre());
			        }
			});
			}
		return this.paradasMetro;
	}
	
	public ArrayList<Parada_bus> getbuses() {
		if(this.paradasbus == null){
			rellenarbus();
			Collections.sort(paradasbus,new Comparator<Parada_bus>() {
				 @Override
			        public int compare(Parada_bus p1, Parada_bus p2)
			        {
	
			            return  p1.getNombre().compareTo(p2.getNombre());
			        }
			});
			}
		return this.paradasbus;
	}
	

	public ArrayList<Restaurante> getRestaurantes() {
		if(this.restaurantes == null){
			rellenarRestaurantes();
			Collections.sort(restaurantes,new Comparator<Restaurante>() {
				 @Override
			        public int compare(Restaurante p1, Restaurante p2)
			        {
	
			            return  p1.getNombre().compareTo(p2.getNombre());
			        }
			});
			}
		return this.restaurantes;
	}
	
	public ArrayList<Ba�o> getBa�os() {
		if(this.ba�os == null){
			rellenarba�os();
			Collections.sort(ba�os,new Comparator<Ba�o>() {
				 @Override
			        public int compare(Ba�o p1, Ba�o p2)
			        {
	
			            return  p1.getDireccion().compareTo(p2.getDireccion());
			        }
			});
			}
		return this.ba�os;
	}
	
	public static String getDBpediaInfo(String uri){
		String qry = "PREFIX " + "owl" + ": <" + pref3 + ">  "
				+ "SELECT DISTINCT ?abstract " 
				+ "WHERE {  <" + uri + "> owl:abstract ?abstract FILTER (lang(?abstract) = 'es' )" + " } ";
	
		Literal abstractStuf = null;
		String sparqlEndpoint = "https://dbpedia.org/sparql";
		QueryEngineHTTP httpQuery = new QueryEngineHTTP(sparqlEndpoint,qry);
		ResultSet results = httpQuery.execSelect();
		while (results.hasNext()) {
			QuerySolution binding = results.nextSolution();
			abstractStuf = binding.getLiteral("abstract");
		}
		if(abstractStuf!=null){
			return abstractStuf.getString();
		}else{
			return "Sin informacion";
		}
	}

	public static void main(String[] args) {
//		String str = "http://dbpedia.org/resource/";
//		System.out.println();
		
		
		Core core = Core.getInstance();
//		System.out.println(core.getDBpediaInfo("http://dbpedia.org/resource/District_line"));
		core.rellenarba�os();
//		for (Parada_bus p : core.getbuses()) {
//			System.out.println(p.getNombre()+" " + p.getCodigoParada());
//		}

	}
}
