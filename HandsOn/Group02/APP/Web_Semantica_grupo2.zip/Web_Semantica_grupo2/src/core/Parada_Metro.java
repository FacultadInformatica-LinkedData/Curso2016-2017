package core;

public class Parada_Metro {

	private String nombre;
	private String paradasAdyacentes;
	private String linea;
	private String coordenadaX;
	private String coordenadaY;
	private String latitud;
	private String longitud;
	private String zona;
	private String codigoPostal;
	
	private Parada_Metro(String nombre,String paradasAdyacetnes,String linea,String x, String y,String lat,String lon,String zona,String cp) {
		
		this.setNombre(nombre);
		this.setparadasAdyacentes(paradasAdyacetnes);
		this.setLinea(linea);
		this.setCoordenadaX(x);
		this.setCoordenadaY(y);
		this.setLatitud(lat);
		this.setLongitud(lon);
		this.setZona(zona);
		this.setCodigoPostal(cp);
	}
	public static Parada_Metro getInstance(String nombreP,String pa,String lineaP,String xP,String yP,String latP,String lonP,String zonaP,String cpP){
		return new Parada_Metro(nombreP,pa, lineaP, xP, yP, latP, lonP, zonaP, cpP);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getLinea() {
		return linea;
	}

	public void setLinea(String linea) {
		this.linea = linea;
	}

	public String getCoordenadaX() {
		return coordenadaX;
	}

	public void setCoordenadaX(String coordenadaX) {
		this.coordenadaX = coordenadaX;
	}

	public String getCoordenadaY() {
		return coordenadaY;
	}

	public void setCoordenadaY(String coordenadaY) {
		this.coordenadaY = coordenadaY;
	}

	public String getLatitud() {
		return latitud;
	}

	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}

	public String getLongitud() {
		return longitud;
	}

	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}

	public String getZona() {
		return zona;
	}

	public void setZona(String zona) {
		this.zona = zona;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}
	public String getparadasAdyacentes() {
		return paradasAdyacentes;
	}
	public void setparadasAdyacentes(String tieneParadasAdyacentes) {
		this.paradasAdyacentes = tieneParadasAdyacentes;
	}
	
}
