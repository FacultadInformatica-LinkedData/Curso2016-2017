package core;

import gui.MainWindow;

public class Main {

	public static void initialise(){
		
	}
	public static void main(String[] args) {
		initialise();
		Core core = Core.getInstance();
		MainWindow mw = new MainWindow(core);
		mw.setVisible(true);
	}
}
