package core;

public class Parada_bus {
	
	private String nombre;
	private String codigoParada;
	private String coordenadaX;
	private String coordenadaY;
	private String sentido;
	private String area;
	
	private Parada_bus(String nombre,String codigo,String x, String y,String sentido,String area) {
		
		this.setNombre(nombre);
		this.setCodigoParada(codigo);
		this.setCoordenadaX(x);
		this.setCoordenadaY(y);
		this.setSentido(sentido);
		this.setArea(area);
	}
	public static Parada_bus getInstance(String nombreP,String cp,String xP,String yP,String sentido,String area){
		return new Parada_bus(nombreP,cp, xP, yP,sentido, area);
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCodigoParada() {
		return codigoParada;
	}
	public void setCodigoParada(String codigoParada) {
		this.codigoParada = codigoParada;
	}
	public String getCoordenadaX() {
		return coordenadaX;
	}
	public void setCoordenadaX(String coordenadaX) {
		this.coordenadaX = coordenadaX;
	}
	public String getCoordenadaY() {
		return coordenadaY;
	}
	public void setCoordenadaY(String coordenadaY) {
		this.coordenadaY = coordenadaY;
	}
	public String getSentido() {
		return sentido;
	}
	public void setSentido(String sentido) {
		this.sentido = sentido;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}

}
