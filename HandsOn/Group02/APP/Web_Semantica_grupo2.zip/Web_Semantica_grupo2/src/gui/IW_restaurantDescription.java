package gui;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import core.Core;
import core.Parada_Metro;
import core.Restaurante;

public class IW_restaurantDescription extends JFrame {
	private JPanel panel;
	
	public IW_restaurantDescription(Restaurante r) {
		
		String nombre = r.getNombre();
		String direccion = r.getDireccion();
		String categoria = r.getCategoria();
		String localizacion = r.getLocalizacion();
		String lat = r.getLatitud();
		String lon = r.getLocalizacion();
		String detalles = r.getDetalles();
		String critica = r.getCritica();
		
		setBackground(Color.WHITE);
		setLayout(null);
		setBounds(1100, 150, 520, 580);
		setSize(520, 580);
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);
		
		
		JLabel nombreLabel = new JLabel("  Nombre:        " + nombre);
		nombreLabel.setSize(500, 60);
		nombreLabel.setBackground(Color.WHITE);
		nombreLabel.setBounds(0, 0, 500, 60);
		nombreLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel DirLabel = new JLabel("   Direcci�n: " + direccion);
		DirLabel.setSize(500, 60);
		DirLabel.setBackground(Color.WHITE);
		DirLabel.setBounds(0, 60, 500, 60);
		DirLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel CategoriaLabel = new JLabel("   Categor�a:  " + categoria);
		CategoriaLabel.setSize(500, 60);
		CategoriaLabel.setBackground(Color.WHITE);
		CategoriaLabel.setBounds(0, 120, 500, 60);
		CategoriaLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel LocalizacionLabel = new JLabel("   Localizacion:  " + localizacion);
		LocalizacionLabel.setSize(500, 60);
		LocalizacionLabel.setBackground(Color.WHITE);
		LocalizacionLabel.setBounds(0, 180, 500, 60);
		LocalizacionLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel latLabel = new JLabel("   Latitud :          " + lat);
		latLabel.setSize(500, 60);
		latLabel.setBackground(Color.WHITE);
		latLabel.setBounds(0, 240, 500, 60);
		latLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel lonLabel = new JLabel("   Longitud :          " + lat);
		lonLabel.setSize(500, 60);
		lonLabel.setBackground(Color.WHITE);
		lonLabel.setBounds(0, 300, 500, 60);
		lonLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel areaLAbel = new JLabel("   �rea:          " + lon);
		areaLAbel.setSize(500, 60);
		areaLAbel.setBackground(Color.WHITE);
		areaLAbel.setBounds(0, 360, 500, 60);
		areaLAbel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		JLabel detallesLabel = new JLabel("   Detalles :          " + detalles);
		detallesLabel.setSize(500, 60);
		detallesLabel.setBackground(Color.WHITE);
		detallesLabel.setBounds(0, 420, 500, 60);
		detallesLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		JLabel criticaLabel = new JLabel("   Cr�tica :          " + critica);
		criticaLabel.setSize(500, 60);
		criticaLabel.setBackground(Color.WHITE);
		criticaLabel.setBounds(0, 480, 500, 60);
		criticaLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		
		panel.add(nombreLabel);
		panel.add(DirLabel);
		panel.add(CategoriaLabel);
		panel.add(LocalizacionLabel);
		panel.add(latLabel);
		panel.add(lonLabel);
		panel.add(areaLAbel);
		panel.add(detallesLabel);
		panel.add(criticaLabel);
		

	}
	
	private String construirHTML(String lineas){
		String[]lineasArr = lineas.split(" | ");
		StringBuilder sb = new StringBuilder();
		sb.append("<html> Lineas : <br>");
		if(lineasArr.length==0){
			return "";
		}else{
			for (int i = 0; i < lineasArr.length; i++) {
				if(!lineasArr[i].contains("|"))
					sb.append(lineasArr[i]+"<br>");
			}
			
		}
		
		sb.append("</html>");
		
		return sb.toString();
	}
	
	//300,150
	private JLabel getDbpediaLabel(String text,int x, int y){
		JLabel  Dbpedia = new JLabel(text);
		Dbpedia.setSize(200, 30);
		Dbpedia.setBackground(Color.green);
		Dbpedia.setBounds(x, y, 200, 30);
		Dbpedia.setBorder(BorderFactory.createLineBorder(Color.GREEN));
		return Dbpedia;
		
		
	}
}
