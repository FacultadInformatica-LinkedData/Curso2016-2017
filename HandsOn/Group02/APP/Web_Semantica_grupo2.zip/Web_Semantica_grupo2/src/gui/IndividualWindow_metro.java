package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import core.Parada_Metro;

public class IndividualWindow_metro extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel label;
	
	public IndividualWindow_metro(Parada_Metro p) {
	
		
		setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		setBackground(Color.WHITE);
		setPreferredSize(new Dimension(600, 50));
		setLayout(null);
		
		label = new JLabel("");
		label.setFont(new Font("Franklin Gothic Demi", Font.PLAIN, 17));
		label.setBounds(10, 11, 612, 28);
		label.setText(p.getNombre());
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				label.setForeground(Color.RED);
				
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				IW_metroDescription iwmd = new IW_metroDescription(p);
				iwmd.setVisible(true);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				label.setForeground(Color.BLACK);
			}
		});
		add(label);
	}
}
