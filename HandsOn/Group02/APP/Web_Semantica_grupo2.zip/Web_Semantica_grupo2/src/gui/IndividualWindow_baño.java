package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import core.Ba�o;
import core.Parada_bus;

public class IndividualWindow_ba�o extends JPanel{

	private JLabel label;
	
	public IndividualWindow_ba�o(Ba�o b) {
	
		
		setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		setBackground(Color.WHITE);
		setPreferredSize(new Dimension(600, 50));
		setLayout(null);
		
		label = new JLabel("");
		label.setFont(new Font("Franklin Gothic Demi", Font.PLAIN, 17));
		label.setBounds(10, 11, 612, 28);
		label.setText(b.getDireccion());
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				label.setForeground(Color.BLUE);
				
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				IW_ba�oDescription iwmd = new IW_ba�oDescription(b);
				iwmd.setVisible(true);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				label.setForeground(Color.BLACK);
			}
		});
		add(label);
	}
}
