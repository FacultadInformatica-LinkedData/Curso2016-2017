package gui;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class DbpediaPanel extends JFrame{
	
	private JPanel panel;
	
	public DbpediaPanel(String text) {
		
		setBackground(Color.WHITE);
		setLayout(null);
		setBounds(1100, 150, 400, 480);
		setSize(800, 300);
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);
		
		String html = construirHTML(text);
		JLabel label = new JLabel(html);
		label.setSize(800, 200);
		label.setBackground(Color.WHITE);
		label.setBounds(0, 0, 800, 200);
		label.setBorder(BorderFactory.createLineBorder(Color.black));
		panel.add(label);
		
	}
	
	private String construirHTML(String lineas){
		String[]lineasArr = lineas.split(" ");
		StringBuilder sb = new StringBuilder();
		sb.append("<html> abstract en Espa�ol: <br>");
		int cont = 0;
		String str = "";
		if(lineasArr.length==0){
			return "";
		}else{
			
			for (int i = 0; i < lineasArr.length; i++) {
				str = str + lineasArr[i] + " ";
				if(str.length()>100){
					cont++;
					sb.append(str);
					sb.append("<br>");
					str ="";
				}
			}
			
		}
		if(cont==0 || !str.equals(""))
			sb.append(str);
		sb.append("</html>");
		
		return sb.toString();
	}

}
