package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import core.Core;


public class MainWindow extends JFrame{

	
	private JPanel panel;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MainWindow(Core core) {
	
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(150, 150, 505, 440);
		setResizable(true);
		setSize(1000, 440);
		panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);

		
		
		JLabel metroLabel= new JLabel("Metro");
		metroLabel.setSize(200, 100);	
		metroLabel.setBackground(Color.WHITE);
		metroLabel.setIcon(new ImageIcon(MainWindow.class.getResource("/resources/metro.jpg")));
		metroLabel.setBounds(0, 0, 1000, 100);
		metroLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		metroLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SecondWindow sw = new SecondWindow(core,"metro");
				sw.setVisible(true);
			}
		});;
		
		
		
		JLabel busLabel= new JLabel("Buses");
		busLabel.setSize(200, 100);
		busLabel.setBackground(Color.WHITE);
		busLabel.setIcon(new ImageIcon(MainWindow.class.getResource("/resources/bus.jpg")));
		busLabel.setBounds(0, 100, 1000, 100);
		busLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		busLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SecondWindow sw = new SecondWindow(core,"bus");
				sw.setVisible(true);
			}
		});;
		
		
		
		JLabel restauranteLabel= new JLabel("Restaurantes");
		restauranteLabel.setSize(200, 100);
		restauranteLabel.setBackground(Color.WHITE);
		restauranteLabel.setIcon(new ImageIcon(MainWindow.class.getResource("/resources/restaurante.jpg")));
		restauranteLabel.setBounds(0, 200,1000, 100);
		restauranteLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		restauranteLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SecondWindow sw = new SecondWindow(core,"restaurante");
				sw.setVisible(true);
			}
		});;
		
		
		
		JLabel ba�oLabel= new JLabel("Ba�os");
		ba�oLabel.setSize(200, 100);
		ba�oLabel.setBackground(Color.WHITE);
		ba�oLabel.setIcon(new ImageIcon(MainWindow.class.getResource("/resources/ba�o.jpg")));
		ba�oLabel.setBounds(0, 300, 1000, 100);
		ba�oLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		ba�oLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SecondWindow sw = new SecondWindow(core,"ba�o");
				sw.setVisible(true);
			}
		});;
		
		
		panel.add(metroLabel);
		panel.add(busLabel);
		panel.add(restauranteLabel);
		panel.add(ba�oLabel);
	}
}
