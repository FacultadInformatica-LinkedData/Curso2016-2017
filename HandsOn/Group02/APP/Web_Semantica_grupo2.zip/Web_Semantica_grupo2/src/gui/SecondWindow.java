package gui;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import core.Ba�o;
import core.Core;
import core.Parada_Metro;
import core.Parada_bus;
import core.Restaurante;

public class SecondWindow extends JFrame {

	private JPanel panel;
	private Core core;

	private final String metro = "metro";
	private final String bus = "bus";
	private final String ba�o = "ba�o";
	private final String restaurante = "restaurante";

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SecondWindow(Core core,String value) {
		this.core= core;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(150, 150, 505, 450);
		setResizable(true);
		setSize(1000, 450);
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);

		JPanel title = new JPanel();
		title.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black));
		title.setBackground(Color.WHITE);
		panel.add(title);

		JLabel labelTitulo = new JLabel("");
		labelTitulo.setBounds(0, 0, 1000, 75);
		switch (value) {
		case metro:
			labelTitulo.setIcon(new ImageIcon(MainWindow.class.getResource("/resources/metro.jpg")));
			labelTitulo.setText("Estaciones de metro");
			break;
		case bus:
			labelTitulo.setIcon(new ImageIcon(MainWindow.class.getResource("/resources/bus.jpg")));
			labelTitulo.setText("Paradas de bus");
			break;
		case ba�o:
			labelTitulo.setIcon(new ImageIcon(MainWindow.class.getResource("/resources/ba�o.jpg")));
			labelTitulo.setText("Ba�os");
			break;
		case restaurante:
			labelTitulo.setIcon(new ImageIcon(MainWindow.class.getResource("/resources/restaurante.jpg")));
			labelTitulo.setText("Restaurante");
			break;
		}
		panel.add(labelTitulo);

		JPanel panelAux = new JPanel();
		panelAux.setBackground(Color.WHITE);
		panelAux.setBounds(10, 112, 632, 361);
		panelAux.setLayout(new BoxLayout(panelAux, BoxLayout.Y_AXIS));

		JScrollPane scrollPanel = new JScrollPane(panelAux);
		scrollPanel.setBounds(50, 100, 800, 300);
		scrollPanel.getVerticalScrollBar().setUnitIncrement(7);
		panel.add(scrollPanel);

		rellenar(value, panelAux);

	}

	private void rellenar(String value, JPanel panelAux) {

		switch (value) {
		case metro:
			for (Parada_Metro p : core.getMetros()) {
				IndividualWindow_metro iwm = new IndividualWindow_metro(p);
				panelAux.add(iwm);
			}
			break;
		case bus:
			for (Parada_bus p : core.getbuses()) {
				IndividualWindow_bus iwm = new IndividualWindow_bus(p);
				panelAux.add(iwm);
			}
			break;
		case ba�o:
			for (Ba�o b : core.getBa�os()) {
				IndividualWindow_ba�o iwm = new IndividualWindow_ba�o(b);
				panelAux.add(iwm);
			}
			break;
		case restaurante:
			for (Restaurante r : core.getRestaurantes()) {
				IndividualWindow_restaurante iwm = new IndividualWindow_restaurante(r);
				panelAux.add(iwm);
			}
			break;
		}

	}
}
