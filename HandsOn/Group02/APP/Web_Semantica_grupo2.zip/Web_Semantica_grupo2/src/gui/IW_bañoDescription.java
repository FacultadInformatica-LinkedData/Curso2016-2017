package gui;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import core.Ba�o;
import core.Restaurante;

public class IW_ba�oDescription extends JFrame{

	private JPanel panel;
	
	public IW_ba�oDescription(Ba�o b) {
		
		String servicio = b.getServicio();
		String direccion = b.getDireccion();
		String x = b.getX();
		String y = b.getY();
		String accesibilidad = b.getAccesibilidad();
		String cambiadorBebe = b.getCambiadorBaby();
		String ba�osFamiliares = b.getBa�osFamiliares();
		String cambiador = b.getCambiador();
		String horaApertura = b.getHoraApertura();
		String administado = b.getAdministradoPor();
		String email = b.getEmail();
		String tel = b.getTel();
		String notas = b.getNotas();
		String cp = b.getCp();
		
		setBackground(Color.WHITE);
		setLayout(null);
		setBounds(1100, 150, 400, 860);
		setSize(520, 880);
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);
		
		
		JLabel nombreLabel = new JLabel("  Servicio:        " + servicio);
		nombreLabel.setSize(500, 60);
		nombreLabel.setBackground(Color.WHITE);
		nombreLabel.setBounds(0, 0, 500, 60);
		nombreLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel DirLabel = new JLabel("   Direcci�n: " + direccion);
		DirLabel.setSize(500, 60);
		DirLabel.setBackground(Color.WHITE);
		DirLabel.setBounds(0, 60, 500, 60);
		DirLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel CoordXLabel = new JLabel("   Coordenada X:  " + x);
		CoordXLabel.setSize(500, 60);
		CoordXLabel.setBackground(Color.WHITE);
		CoordXLabel.setBounds(0, 120, 500, 60);
		CoordXLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel CoordYLabel = new JLabel("   Coordenada Y:  " + y);
		CoordYLabel.setSize(500, 60);
		CoordYLabel.setBackground(Color.WHITE);
		CoordYLabel.setBounds(0, 180, 500, 60);
		CoordYLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel AccesibilidadLabel = new JLabel("   Accesibilidad :          " + accesibilidad);
		AccesibilidadLabel.setSize(500, 60);
		AccesibilidadLabel.setBackground(Color.WHITE);
		AccesibilidadLabel.setBounds(0, 240, 500, 60);
		AccesibilidadLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel ba�osfamiliareslabel = new JLabel("   Ba�os Familiares :          " + ba�osFamiliares);
		ba�osfamiliareslabel.setSize(500, 60);
		ba�osfamiliareslabel.setBackground(Color.WHITE);
		ba�osfamiliareslabel.setBounds(0, 300, 500, 60);
		ba�osfamiliareslabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel CambiadorBebesLabel = new JLabel("   Cambiador Bebe:          " + cambiadorBebe);
		CambiadorBebesLabel.setSize(500, 60);
		CambiadorBebesLabel.setBackground(Color.WHITE);
		CambiadorBebesLabel.setBounds(0, 360, 500, 60);
		CambiadorBebesLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		JLabel CambiadorLabel = new JLabel("   Cambiador :          " + cambiador);
		CambiadorLabel.setSize(500, 60);
		CambiadorLabel.setBackground(Color.WHITE);
		CambiadorLabel.setBounds(0, 420, 500, 60);
		CambiadorLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		JLabel HoraAperturaLabel = new JLabel("   Hora Apertura :          " + horaApertura);
		HoraAperturaLabel.setSize(500, 60);
		HoraAperturaLabel.setBackground(Color.WHITE);
		HoraAperturaLabel.setBounds(0, 480, 500, 60);
		HoraAperturaLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		JLabel AdminLabel = new JLabel("   Administrado por :          " + administado);
		AdminLabel.setSize(500, 60);
		AdminLabel.setBackground(Color.WHITE);
		AdminLabel.setBounds(0, 540, 500, 60);
		AdminLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		
		JLabel emailLabel = new JLabel("   Email :          " + email);
		emailLabel.setSize(500, 60);
		emailLabel.setBackground(Color.WHITE);
		emailLabel.setBounds(0, 600, 500, 60);
		emailLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		JLabel telLabel = new JLabel("   Telefono :          " + tel);
		telLabel.setSize(500, 60);
		telLabel.setBackground(Color.WHITE);
		telLabel.setBounds(0, 660, 500, 60);
		telLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		JLabel notasLabel = new JLabel("   Notas :          " + notas);
		notasLabel.setSize(500, 60);
		notasLabel.setBackground(Color.WHITE);
		notasLabel.setBounds(0, 720, 500, 60);
		notasLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		JLabel CPLavel = new JLabel("   C�digo Postal :          " + cp);
		CPLavel.setSize(500, 60);
		CPLavel.setBackground(Color.WHITE);
		CPLavel.setBounds(0, 780, 500, 60);
		CPLavel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		
		panel.add(nombreLabel);
		panel.add(DirLabel);
		panel.add(CoordXLabel);
		panel.add(CoordYLabel);
		panel.add(ba�osfamiliareslabel);
		panel.add(AccesibilidadLabel);
		panel.add(CambiadorBebesLabel);
		panel.add(CambiadorLabel);
		panel.add(HoraAperturaLabel);
		panel.add(AdminLabel);
		panel.add(emailLabel);
		panel.add(telLabel);
		panel.add(notasLabel);
		panel.add(CPLavel);
		

	}
	
	private String construirHTML(String lineas){
		String[]lineasArr = lineas.split(" | ");
		StringBuilder sb = new StringBuilder();
		sb.append("<html> Lineas : <br>");
		if(lineasArr.length==0){
			return "";
		}else{
			for (int i = 0; i < lineasArr.length; i++) {
				if(!lineasArr[i].contains("|"))
					sb.append(lineasArr[i]+"<br>");
			}
			
		}
		
		sb.append("</html>");
		
		return sb.toString();
	}
	
	//300,150
	private JLabel getDbpediaLabel(String text,int x, int y){
		JLabel  Dbpedia = new JLabel(text);
		Dbpedia.setSize(200, 30);
		Dbpedia.setBackground(Color.green);
		Dbpedia.setBounds(x, y, 200, 30);
		Dbpedia.setBorder(BorderFactory.createLineBorder(Color.GREEN));
		return Dbpedia;
		
		
	}
}
