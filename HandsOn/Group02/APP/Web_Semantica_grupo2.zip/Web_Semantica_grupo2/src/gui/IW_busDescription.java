package gui;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import core.Core;
import core.Parada_Metro;
import core.Parada_bus;

public class IW_busDescription extends JFrame{
private JPanel panel;
	
	public IW_busDescription(Parada_bus p) {
		
		String nombre = p.getNombre();
		String cp = p.getCodigoParada();
		String coordx = p.getCoordenadaX();
		String coordy = p.getCoordenadaY();
		String sentido = p.getSentido();
		String area = p.getArea();
		
		
		setBackground(Color.WHITE);
		setLayout(null);
		setBounds(1100, 150, 400, 480);
		setSize(520, 400);
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);
		
		
		JLabel nombreLabel = new JLabel("   Nombre:        " + nombre);
		nombreLabel.setSize(500, 60);
		nombreLabel.setBackground(Color.WHITE);
		nombreLabel.setBounds(0, 0, 500, 60);
		nombreLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel cpLabel = new JLabel("   C�digo de parada: " + cp);
		cpLabel.setSize(500, 60);
		cpLabel.setBackground(Color.WHITE);
		cpLabel.setBounds(0, 60, 500, 60);
		cpLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel CoordXLabel = new JLabel("   Coordenada-X:  " + coordx);
		CoordXLabel.setSize(500, 60);
		CoordXLabel.setBackground(Color.WHITE);
		CoordXLabel.setBounds(0, 120, 500, 60);
		CoordXLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel CoordYLabel = new JLabel("   Coordenada-Y:  " + coordy);
		CoordYLabel.setSize(500, 60);
		CoordYLabel.setBackground(Color.WHITE);
		CoordYLabel.setBounds(0, 180, 500, 60);
		CoordYLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel sentidoLabel = new JLabel("   Sentido :          " + sentido);
		sentidoLabel.setSize(500, 60);
		sentidoLabel.setBackground(Color.WHITE);
		sentidoLabel.setBounds(0, 240, 500, 60);
		sentidoLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel areaLabel = new JLabel("   �rea:          " + area);
		areaLabel.setSize(500, 60);
		areaLabel.setBackground(Color.WHITE);
		areaLabel.setBounds(0, 300, 500, 60);
		areaLabel.setBorder(BorderFactory.createLineBorder(Color.black));	
		
		
		panel.add(nombreLabel);
		panel.add(cpLabel);
		panel.add(CoordXLabel);
		panel.add(CoordYLabel);
		panel.add(sentidoLabel);
		panel.add(areaLabel);

	}
	
	private String construirHTML(String lineas){
		String[]lineasArr = lineas.split(" | ");
		StringBuilder sb = new StringBuilder();
		sb.append("<html> Lineas : <br>");
		if(lineasArr.length==0){
			return "";
		}else{
			for (int i = 0; i < lineasArr.length; i++) {
				if(!lineasArr[i].contains("|"))
					sb.append(lineasArr[i]+"<br>");
			}
			
		}
		
		sb.append("</html>");
		
		return sb.toString();
	}
	
}
