package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.xerces.impl.dv.DVFactoryException;

import core.Core;
import core.Parada_Metro;

public class IW_metroDescription extends JFrame {
	
	private JPanel panel;
	
	public IW_metroDescription(Parada_Metro p) {
		
		String nombre = p.getNombre();
		String pa = p.getparadasAdyacentes();
		String linea = p.getLinea();
		String coordx = p.getCoordenadaX();
		String coordy = p.getCoordenadaY();
		String lat = p.getLatitud();
		String lon = p.getLongitud();
		String zona = p.getZona();
		String cp = p.getCodigoPostal();
		String[] arrL  = linea.split(" | ");
		
		setBackground(Color.WHITE);
		setLayout(null);
		setBounds(1100, 150, 400, 480);
		setSize(520, 640);
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(null);
		
		
		JLabel nombreLabel = new JLabel("   Nombre:        " + nombre);
		nombreLabel.setSize(500, 60);
		nombreLabel.setBackground(Color.WHITE);
		nombreLabel.setBounds(0, 0, 500, 60);
		nombreLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel paLabel = new JLabel("   Paradas Adyacentes: " + pa);
		paLabel.setSize(500, 60);
		paLabel.setBackground(Color.WHITE);
		paLabel.setBounds(0, 60, 500, 60);
		paLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		String lineaHTML = construirHTML(linea);
		JLabel LineaLabel = new JLabel(lineaHTML);
		LineaLabel.setSize(500, 120);
		LineaLabel.setBackground(Color.WHITE);
		LineaLabel.setBounds(0, 120, 500, 120);
		LineaLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		int x= 300;
		int y = 120;
		String aux = "" ;
		for ( String linea1 : arrL) {
			
			if(!linea1.contains("|") && linea1.contains("http") && !linea1.equals(aux)){
				String str = linea1.substring(28);
				JLabel dbpedia = getDbpediaLabel(str+ " dbpedia", x, y);
				dbpedia.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						String txt = Core.getDBpediaInfo(linea1);
						DbpediaPanel db = new DbpediaPanel(txt);
						db.setVisible(true);
					}
				});
				panel.add(dbpedia);
				y = y + 30;
				aux = linea1;
			}
		}
		
		
		
		
		JLabel CoordXLabel = new JLabel("   Coordenada-X:  " + coordx);
		CoordXLabel.setSize(500, 60);
		CoordXLabel.setBackground(Color.WHITE);
		CoordXLabel.setBounds(0, 240, 500, 60);
		CoordXLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel CoordYLabel = new JLabel("   Coordenada-Y:  " + coordy);
		CoordYLabel.setSize(500, 60);
		CoordYLabel.setBackground(Color.WHITE);
		CoordYLabel.setBounds(0, 300, 500, 60);
		CoordYLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JLabel LatLabel = new JLabel("   Latitud:          " + lat);
		LatLabel.setSize(500, 60);
		LatLabel.setBackground(Color.WHITE);
		LatLabel.setBounds(0, 360, 500, 60);
		LatLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel LonLabel = new JLabel("   Longitud:          " + lon);
		LonLabel.setSize(500, 60);
		LonLabel.setBackground(Color.WHITE);
		LonLabel.setBounds(0, 420, 500, 60);
		LonLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel zonaLabel = new JLabel("   Zona:          " + zona);
		zonaLabel.setSize(500, 60);
		zonaLabel.setBackground(Color.WHITE);
		zonaLabel.setBounds(0, 480, 500, 60);
		zonaLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel cpLabel = new JLabel("   Codigo Postal:          " + cp);
		cpLabel.setSize(500, 60);
		cpLabel.setBackground(Color.WHITE);
		cpLabel.setBounds(0, 540, 500, 60);
		cpLabel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		
		
		
		panel.add(nombreLabel);
		panel.add(paLabel);
		panel.add(LineaLabel);
		panel.add(CoordXLabel);
		panel.add(CoordYLabel);
		panel.add(LatLabel);
		panel.add(LonLabel);
		panel.add(zonaLabel);
		panel.add(cpLabel);

	}
	
	private String construirHTML(String lineas){
		String[]lineasArr = lineas.split(" | ");
		StringBuilder sb = new StringBuilder();
		sb.append("<html> Lineas : <br>");
		if(lineasArr.length==0){
			return "";
		}else{
			for (int i = 0; i < lineasArr.length; i++) {
				if(!lineasArr[i].contains("|"))
					sb.append(lineasArr[i]+"<br>");
			}
			
		}
		
		sb.append("</html>");
		
		return sb.toString();
	}
	
	//300,150
	private JLabel getDbpediaLabel(String text,int x, int y){
		JLabel  Dbpedia = new JLabel(text);
		Dbpedia.setSize(200, 30);
		Dbpedia.setBackground(Color.green);
		Dbpedia.setBounds(x, y, 200, 30);
		Dbpedia.setBorder(BorderFactory.createLineBorder(Color.GREEN));
		return Dbpedia;
		
		
	}

}
